package gestionAeroport;

import java.util.concurrent.TimeUnit;

public class VolDeLigne extends Vol {	
	private TourDeControle aeroportActuel;	
	boolean PretPourAtterissage;
	boolean PretPourDecolage;	
	public VolDeLigne(TourDeControle _a, boolean _att, boolean _decol){
		aeroportActuel = _a;
		PretPourAtterissage = _att;
		PretPourDecolage = _decol;
	}			
	public void atterir(Piste p) {
        System.out.println("Atterissage en cours sur la piste assign�e...");       
        try {
			TimeUnit.MINUTES.sleep(1);			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}      
      }
	public void decoler(Piste p) {
		System.out.println("Decolage en cours sur la piste assign�e...");       
        try {
			TimeUnit.MINUTES.sleep(1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}	
	public void autoriser(Piste p) {		
		if (PretPourAtterissage) {
			atterir(p);
		} else if(PretPourDecolage) {
			decoler(p);
		}		
	}
}
