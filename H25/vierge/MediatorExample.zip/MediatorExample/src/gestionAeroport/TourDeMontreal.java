package gestionAeroport;

import java.util.*;

public class TourDeMontreal extends TourDeControle {
	
	private Piste piste = new Piste();
	private Queue<Vol> fileAttente = new LinkedList<Vol>();
	
	public void enregistrer(Vol v) {
		fileAttente.add(v);
	}
	
	public void supprimer(Vol v) {
		fileAttente.remove(v);
	}
	
	public void assignerPiste() {
		Vol v = fileAttente.peek();
		v.autoriser(piste);		
	}
	
}
