package gestionAeroport;

public abstract class TourDeControle {
	
	public abstract void enregistrer(Vol v);
	public abstract void supprimer(Vol v);
	public abstract void assignerPiste();	

}
