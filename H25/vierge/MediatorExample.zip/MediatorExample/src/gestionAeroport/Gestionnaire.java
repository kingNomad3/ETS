package gestionAeroport;


public class Gestionnaire {	
	public static void main(String args[]) {		
		//On cr�e le m�diateur
		TourDeControle tour1 = new TourDeMontreal();
		
		//on cr�e les vols en leur passant le m�diateur en param�tre
		//cr�ation d'un vol qui veut atterir
		Vol vol1 = new VolDeLigne(tour1, true, false); 
		
		//le vol s'enregistre dans la file d'attente		
		tour1.enregistrer(vol1);
		
		//cr�ation d'un vol qui veut decoler	
		Vol vol2 = new VolDeLigne(tour1, false, true);
		tour1.enregistrer(vol2);
		
		tour1.assignerPiste();
		tour1.supprimer(vol1);
		
		tour1.assignerPiste();
		tour1.supprimer(vol2);
	}
}
