package gestionAeroport;

public abstract class Vol {	
			
	public abstract void autoriser(Piste p);   	
	public abstract void atterir(Piste p);           
	public abstract void decoler(Piste p);    
    
}
