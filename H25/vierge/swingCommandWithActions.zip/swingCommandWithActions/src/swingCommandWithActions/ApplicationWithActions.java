package swingCommandWithActions;

import java.awt.Component;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class ApplicationWithActions extends JFrame {
	
	  private JButton openButton = new JButton("Ouvrir");
	  private JButton exitButton = new JButton("Quitter");	
	  
	  public ApplicationWithActions() {		
	      super("Mon application");
	      setSize(400, 400);
	      JPanel myPanel = new JPanel();
	      myPanel.add(openButton);
	      myPanel.add(exitButton);		
	      add(myPanel);		
	      openButton.setAction(new OpenAction());
	      exitButton.setAction(new ExitAction());
	  }	
	 
	  public static void main(String[] argv) {
		  ApplicationWithActions application = new ApplicationWithActions();		
	      application.setVisible(true);		
	  }		
	}
