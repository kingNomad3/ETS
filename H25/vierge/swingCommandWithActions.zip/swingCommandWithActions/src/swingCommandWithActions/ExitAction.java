package swingCommandWithActions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

public class ExitAction extends AbstractAction {

	public ExitAction() {
		super("exit");
	}
	public void actionPerformed(ActionEvent event) {
	      System.exit(0);
	  }	
}
