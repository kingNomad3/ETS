package swingCommandWithActions;

import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;

public class OpenAction extends AbstractAction{

	public OpenAction() {
		super("open");
	}
	public void actionPerformed(ActionEvent event) {
		JOptionPane.showMessageDialog((Component)event.getSource(), "Ouvrir");
	  }	
	
}
