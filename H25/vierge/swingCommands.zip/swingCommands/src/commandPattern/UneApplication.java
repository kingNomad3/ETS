package commandPattern;

import java.awt.Component;
import java.awt.event.*;

import javax.swing.*;

public class UneApplication extends JFrame implements ActionListener {
	  private JButton openButton = new JButton("Ouvrir");
	  private JButton exitButton = new JButton("Quitter");	
	  public UneApplication() {		
	      super("Mon application");
	      setSize(400, 400);
	      JPanel myPanel = new JPanel();
	      myPanel.add(openButton);
	      myPanel.add(exitButton);		
	      add(myPanel);		
	      openButton.addActionListener(this);
	      exitButton.addActionListener(this);
	  }	
	  public void actionPerformed(ActionEvent event) {
	      if (event.getSource()== openButton)
	         JOptionPane.showMessageDialog((Component)event.getSource(), "Ouvrir");
	      else if (event.getSource()== exitButton)
	         System.exit(0);
	  }	
	  public static void main(String[] argv) {
	      UneApplication application = new UneApplication();		
	      application.setVisible(true);		
	  }		
	}