package mvcExemple;

public class MVCTempConvert 
{	public static void main(String args[]) 
	{	TemperatureModel temperature = new TemperatureModel();
		new FarenheitGUI(temperature, 300, 100);
		new CelsiusGUI(temperature,300, 250);
		new SliderGUI(temperature, 500, 500);
	}
}
