public class Cercle extends Forme {
    public Cercle(String nom){
        super(nom);
    }
}
