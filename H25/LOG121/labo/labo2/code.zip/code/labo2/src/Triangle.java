public class Triangle extends Forme {
    public Triangle(String nom){
        super(nom);
    }
}
