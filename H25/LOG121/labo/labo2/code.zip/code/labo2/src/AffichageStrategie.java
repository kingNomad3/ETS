public interface AffichageStrategie {
    void afficher(ComposantDessin composant, int niveau, String chemin);

}
