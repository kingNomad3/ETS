public class Rectangle extends Forme{
    public Rectangle(String nom){
        super(nom);
    }
}
