public interface Observateur {
    void mettreAJour(Capteur capteur);
}
