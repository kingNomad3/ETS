public class CapteurTemperature extends Capteur {

    public CapteurTemperature(float valeurInitiale) {
        super(valeurInitiale);
    }

    @Override
    public String toString() {
        return "Capteur de température";
    }
}
