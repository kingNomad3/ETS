public class CapteurCO2 extends Capteur {

    public CapteurCO2(float valeurInitiale) {
        super(valeurInitiale);
    }

    @Override
    public String toString() {
        return "Capteur de CO2";
    }
}
